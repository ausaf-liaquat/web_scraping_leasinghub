from leasinghub.leasinghub import loadLeasinghub


if __name__ == "__main__":
    loadLeasinghub()
